module.exports = {
  preset: 'react-native',
  transformIgnorePatterns: [
    "node_modules/(?!(@react-native|react-native|@react-native-async-storage|expo(nent)?|@expo(nent)?/.*|expo-.*|@expo/.*|@unimodules/.*|unimodules|sentry-expo|native-base|react-clone-referenced-element|react-native-svg|react-native-.*)/)"
  ],
  testEnvironment: 'jsdom',
};
