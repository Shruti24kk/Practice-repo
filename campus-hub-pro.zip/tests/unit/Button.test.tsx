import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import Button from '../../src/components/Button';

test('button calls onPress', ()=>{
  const cb = jest.fn();
  const { getByA11yRole } = render(<Button title="Hello" onPress={cb} />);
  fireEvent.press(getByA11yRole('button'));
  expect(cb).toHaveBeenCalled();
});
