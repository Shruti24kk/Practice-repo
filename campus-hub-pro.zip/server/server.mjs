import express from 'express';
import cors from 'cors';
const app = express();
app.use(cors());
app.use(express.json());

let tasks = [
  { id: 'a1', title: 'Read Chapter 3', done: false },
  { id: 'b2', title: 'Build RN screens', done: true },
];

app.get('/tasks', (req,res)=>{
  const q = (req.query.q||'').toString().toLowerCase();
  const data = q? tasks.filter(t=> t.title.toLowerCase().includes(q)) : tasks;
  res.json(data);
});
app.get('/tasks/:id', (req,res)=>{
  const t = tasks.find(x=> x.id === req.params.id);
  if (!t) return res.status(404).json({error:'Not found'});
  res.json(t);
});
app.post('/tasks', (req,res)=>{
  const title = String(req.body?.title||'').trim();
  if (!title) return res.status(400).json({error:'title required'});
  const t = { id: Math.random().toString(36).slice(2), title, done:false };
  tasks.unshift(t);
  res.status(201).json(t);
});
app.patch('/tasks/:id/toggle', (req,res)=>{
  const t = tasks.find(x=> x.id === req.params.id);
  if (!t) return res.status(404).json({error:'Not found'});
  t.done = !t.done; res.json(t);
});
app.delete('/tasks/:id', (req,res)=>{
  tasks = tasks.filter(x=> x.id !== req.params.id);
  res.status(204).end();
});

const port = process.env.PORT || 3333;
app.listen(port, ()=> console.log(`Mock server running on http://localhost:${port}`));
