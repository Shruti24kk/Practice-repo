import Constants from 'expo-constants';
const BASE_URL = (Constants.expoConfig?.extra as any)?.API_BASE_URL || 'http://localhost:3333';

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(init?.headers||{}) },
    ...init,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HTTP ${res.status}: ${text}`);
  }
  return res.json() as Promise<T>;
}

export const Endpoints = {
  tasks: {
    list: (q?: string) => api<{id:string; title:string; done:boolean}[]>(`/tasks${q?`?q=${encodeURIComponent(q)}`:''}`),
    get: (id: string) => api(`/tasks/${id}`),
    create: (body: {title:string}) => api(`/tasks`, { method: 'POST', body: JSON.stringify(body) }),
    toggle: (id: string) => api(`/tasks/${id}/toggle`, { method: 'PATCH' }),
    remove: (id: string) => api(`/tasks/${id}`, { method: 'DELETE' }),
  }
};
