import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabaseSync('campus.db');

db.execSync('CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, title TEXT, done INT, updated_at INT);');

export const DB = {
  upsertTasks(rows: {id:string; title:string; done:number; updated_at:number}[]) {
    const tx = db.transactionSync();
    for (const r of rows) {
      tx.executeSqlSync('REPLACE INTO tasks (id,title,done,updated_at) VALUES (?,?,?,?)',[r.id,r.title,r.done,r.updated_at]);
    }
    tx.commit();
  },
  allTasks(): {id:string; title:string; done:number; updated_at:number}[] {
    const rs = db.getAllSync('SELECT id,title,done,updated_at FROM tasks ORDER BY updated_at DESC');
    return rs as any;
  }
};
