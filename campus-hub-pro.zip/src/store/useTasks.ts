import { create } from 'zustand';
import { Endpoints } from '../lib/api';
import { DB } from '../lib/db';

type Task = { id: string; title: string; done: boolean; updated_at?: number };

type State = {
  tasks: Task[];
  loading: boolean;
  fetch: (q?: string)=> Promise<void>;
  add: (title: string)=> Promise<void>;
  toggle: (id: string)=> Promise<void>;
  remove: (id: string)=> Promise<void>;
};

export const useTasks = create<State>((set, get)=> ({
  tasks: DB.allTasks().map(r=> ({ id: r.id, title: r.title, done: !!r.done, updated_at: r.updated_at })),
  loading: false,
  async fetch(q) {
    set({ loading: true });
    try {
      const server = await Endpoints.tasks.list(q);
      const rows = server.map(t=> ({ id: t.id, title: t.title, done: t.done?1:0, updated_at: Date.now() }));
      DB.upsertTasks(rows);
      set({ tasks: DB.allTasks().map(r=> ({ id:r.id, title:r.title, done:!!r.done, updated_at:r.updated_at }))});
    } finally { set({ loading: false }); }
  },
  async add(title) {
    const optimistic = { id: Math.random().toString(36).slice(2), title, done:false, updated_at: Date.now() };
    set({ tasks: [optimistic, ...get().tasks] });
    try { await Endpoints.tasks.create({ title }); } catch {}
  },
  async toggle(id) { await Endpoints.tasks.toggle(id); await get().fetch(); },
  async remove(id) { await Endpoints.tasks.remove(id); set({ tasks: get().tasks.filter(t=> t.id!==id) }); }
}));
