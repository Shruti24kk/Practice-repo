import React, { createContext, useContext, useMemo, useState } from 'react';
import { useColorScheme as useRNColorScheme } from 'react-native';

type Theme = 'light' | 'dark';
const ThemeContext = createContext<{theme: Theme; toggle: ()=>void}>({theme:'light', toggle: ()=>{}});

export const ThemeProvider: React.FC<{children: React.ReactNode}> = ({children}) => {
  const sys = useRNColorScheme();
  const [theme, setTheme] = useState<Theme>((sys ?? 'light') as Theme);
  const value = useMemo(()=>({ theme, toggle: ()=> setTheme(p=> p==='light'?'dark':'light') }),[theme]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export const useTheme = () => useContext(ThemeContext);

export const palette = {
  light: { bg: '#FFFFFF', text:'#111827', primary:'#2563eb', card:'#F3F4F6', border:'#E5E7EB' },
  dark:  { bg: '#0B1220', text:'#E5E7EB', primary:'#60A5FA', card:'#111827', border:'#1F2937' },
};
