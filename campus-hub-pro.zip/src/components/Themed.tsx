import React from 'react';
import { View, Text, ViewProps, TextProps } from 'react-native';
import { useTheme, palette } from '../styles/theme';

export const ThemedView: React.FC<ViewProps & {card?: boolean}> = ({style, card, ...rest}) => {
  const { theme } = useTheme();
  const colors = palette[theme];
  return <View style={[{ backgroundColor: card? colors.card : colors.bg }, style]} {...rest}/>;
};

export const ThemedText: React.FC<TextProps & {variant?: 'title'|'body'|'caption'}> = ({style, variant='body', ...rest}) => {
  const { theme } = useTheme();
  const colors = palette[theme];
  const base = variant==='title'? {fontSize:22, fontWeight:'700'}: variant==='caption'? {fontSize:12, opacity:0.8}:{fontSize:16};
  return <Text style={[{ color: colors.text }, base, style]} {...rest}/>;
};
