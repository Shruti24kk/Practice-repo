import React from 'react';
import { Pressable, ActivityIndicator } from 'react-native';
import { ThemedText } from './Themed';
import { useTheme, palette } from '../styles/theme';

export default function Button({ title, onPress, loading }: { title: string; onPress?: ()=>void; loading?: boolean }){
  const { theme } = useTheme();
  const colors = palette[theme];
  return (
    <Pressable accessibilityRole="button" style={({pressed})=>({
      backgroundColor: colors.primary, padding:14, borderRadius:12, opacity: pressed?0.85:1, alignItems:'center'})}
      onPress={onPress}>
      {loading? <ActivityIndicator/>: <ThemedText style={{color: 'white', fontWeight:'700'}}>{title}</ThemedText>}
    </Pressable>
  );
}
