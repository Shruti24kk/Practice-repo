import React from 'react';
import { Image, View } from 'react-native';
import { ThemedText, ThemedView } from '../../src/components/Themed';

export default function Profile(){
  return (
    <ThemedView style={{ flex:1, padding:24 }}>
      <View style={{ alignItems:'center', gap:12, padding:16, borderWidth:1, borderRadius:16 }}>
        <View style={{ width:120, height:120, borderRadius:60, overflow:'hidden', borderWidth:2, alignItems:'center', justifyContent:'center' }}>
          <Image source={{ uri:'https://i.pravatar.cc/240' }} style={{ width:116, height:116, borderRadius:58 }} />
        </View>
        <ThemedText variant="title">Alex Developer</ThemedText>
        <ThemedText variant="caption">Mobile Engineer • Seattle</ThemedText>
      </View>
    </ThemedView>
  );
}
