import React, { useEffect, useState } from 'react';
import { FlatList, RefreshControl, TextInput, View } from 'react-native';
import { ThemedText, ThemedView } from '../../src/components/Themed';
import Button from '../../src/components/Button';
import { useTasks } from '../../src/store/useTasks';

export default function Tasks(){
  const { tasks, fetch, add, toggle, remove, loading } = useTasks();
  const [q, setQ] = useState('');
  useEffect(()=>{ fetch(); },[]);

  return (
    <ThemedView style={{ flex:1 }}>
      <View style={{ padding:12, gap:8 }}>
        <TextInput accessibilityLabel="Search tasks" placeholder="Search" onChangeText={setQ}
          onSubmitEditing={()=>fetch(q)} style={{ borderWidth:1, borderRadius:10, padding:12 }} />
        <View style={{ flexDirection:'row', gap:8 }}>
          <TextInput placeholder="New task title" onSubmitEditing={(e)=> add(e.nativeEvent.text)}
            style={{ flex:1, borderWidth:1, borderRadius:10, padding:12 }} />
          <Button title="Add" onPress={()=>{}} />
        </View>
      </View>
      <FlatList data={tasks} keyExtractor={i=>i.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={()=>fetch(q)} />} 
        ListEmptyComponent={<ThemedText style={{textAlign:'center', marginTop:40}}>No tasks yet</ThemedText>}
        renderItem={({item})=> (
          <View style={{ padding:12, marginHorizontal:12, marginVertical:6, borderRadius:12, borderWidth:1, flexDirection:'row', alignItems:'center', justifyContent:'space-between' }}>
            <ThemedText style={{ textDecorationLine: item.done? 'line-through':'none' }}>{item.title}</ThemedText>
            <View style={{ flexDirection:'row', gap:8 }}>
              <Button title={item.done? 'Undo':'Done'} onPress={()=> toggle(item.id)} />
              <Button title="Delete" onPress={()=> remove(item.id)} />
            </View>
          </View>
        )}
      />
    </ThemedView>
  );
}
