import React, { useEffect } from 'react';
import { ThemedText, ThemedView } from '../../src/components/Themed';
import Button from '../../src/components/Button';
import { useTheme } from '../../src/styles/theme';

export default function Home(){
  const { toggle } = useTheme();
  useEffect(()=>{},[]);
  return (
    <ThemedView style={{ flex:1, padding:16, justifyContent:'center', gap:16 }}>
      <ThemedText variant="title">Welcome to CampusHub Pro</ThemedText>
      <ThemedText>An advanced Expo app template featuring networking, offline cache, theming, accessibility, tests, and CI-ready setup.</ThemedText>
      <Button title="Toggle Theme" onPress={toggle} />
    </ThemedView>
  );
}
