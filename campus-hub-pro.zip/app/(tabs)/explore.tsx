import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { ThemedView, ThemedText } from '../../src/components/Themed';

async function fetchMovies(){
  const r = await fetch('https://reactnative.dev/movies.json');
  return r.json() as Promise<{ title: string; description: string; movies: {id:string; title:string; releaseYear:string}[] }>;
}

export default function Explore(){
  const { data, error, isLoading } = useQuery({ queryKey:['movies'], queryFn: fetchMovies });
  if (isLoading) return <ThemedView style={{flex:1, justifyContent:'center', alignItems:'center'}}><ThemedText>Loading…</ThemedText></ThemedView>;
  if (error) return <ThemedView style={{flex:1, justifyContent:'center', alignItems:'center'}}><ThemedText>Failed to load.</ThemedText></ThemedView>;
  return (
    <ThemedView style={{ flex:1, padding:16 }}>
      <ThemedText variant="title">{data?.title}</ThemedText>
      <ThemedText style={{marginBottom:12}}>{data?.description}</ThemedText>
      {data?.movies?.map(m=> (
        <ThemedText key={m.id}>• {m.title} ({m.releaseYear})</ThemedText>
      ))}
    </ThemedView>
  );
}
