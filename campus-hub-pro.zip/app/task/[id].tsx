import React from 'react';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { View, TextInput } from 'react-native';
import Button from '../../src/components/Button';
import { ThemedView, ThemedText } from '../../src/components/Themed';
import { useTasks } from '../../src/store/useTasks';

const schema = z.object({ title: z.string().min(1).max(120) });

type Form = z.infer<typeof schema>;

export default function TaskDetail(){
  const { id } = useLocalSearchParams<{id: string}>();
  const router = useRouter();
  const { tasks, add } = useTasks();
  const task = tasks.find(t=> t.id === id);
  const { register, handleSubmit, setValue } = useForm<Form>({ resolver: zodResolver(schema), defaultValues: { title: task?.title || '' } });

  return (
    <ThemedView style={{ flex:1, padding:16, gap:12 }}>
      <ThemedText variant="title">Edit Task</ThemedText>
      <TextInput {...register('title')} onChangeText={(t)=> setValue('title', t)} style={{ borderWidth:1, borderRadius:10, padding:12 }} />
      <View style={{ flexDirection:'row', gap:8 }}>
        <Button title="Save" onPress={handleSubmit(async (v)=> { await add(v.title); router.back(); })} />
        <Button title="Cancel" onPress={()=> router.back()} />
      </View>
    </ThemedView>
  );
}
